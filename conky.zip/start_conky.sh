#!/bin/bash
killall conky
sleep 10
conky -c ~/.conky/Izar/Izar-new
