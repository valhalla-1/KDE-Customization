# ts-dark
A dark transparent Ulauncher theme

Transparency is not really a viable option IMO when theming something like ulauncher as readabilty is key,
but with that said I created it anyway.

## Screenshot
![](https://i.ibb.co/yQ9rC1D/ts-dark.jpg)

## Installation
Copy or git clone this repo to ~/.config/ulauncher/user-themes/
